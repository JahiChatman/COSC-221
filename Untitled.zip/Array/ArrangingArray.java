
import java.util.Scanner;

public class ArrangingArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	int[] testing = {2230, 3400, 2350, 4000};
	
	
	
	int[] a = new int[4]; 
	Scanner sc = new Scanner(System.in); 
	
		System.out.println("Enter four numbers");
		
		
		for(int n= 0; n < 4; n++) {
			a[n] = sc.nextInt();
		}
	
	sc.close();
	
	
	}






}
